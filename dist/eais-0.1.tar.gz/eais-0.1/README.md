# eais

This "eais" package contains several common utilities modules

   ## Installation

``` 
     pip install eais
```

   ## Usage

``` python
     import eais.mybag
     import eais.myutils
     import eais.util_jupyter
```

   ## License

   This project is licensed under the MIT License - see the LICENSE file for details.